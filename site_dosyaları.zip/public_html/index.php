<?php 
include '_controller/cekirdek_yapi.php';
include '_wiever/site.php';
?>