<?php 
$site_url="http://sfps.site/";
//$admin_url="http://sfps.site/";
$firma_ismi="Nem Sensor Projesi";
?>
